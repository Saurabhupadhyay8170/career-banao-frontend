const BaseUrl = "https://cbapi.careerbanao.org/apis/legacy/client/V1/Resource/";
export const FileUploadUrl = "https://cbfup.careerbanao.org/legacy/client/V1/Resource/fileUpload"
export default BaseUrl;

export const onlineFormBaseUrl = "https://cbapi.careerbanao.org/apis/legacy/client/V1/Store"