import React, { useState } from 'react';

interface FAQItem {
  question: string;
  answer: string;
}

const Faq: React.FC = () => {
  const [selectedIndex, setSelectedIndex] = useState<number | null>(null);

  const faqs: FAQItem[] = [
    {
      question: "What is CareerBanao?",
      answer: "CareerBanao is an online platform offering career counseling, admission guidance, and coaching to help students achieve their educational goals.",
    },
    {
      question: "How can I apply for career counseling?",
      answer: "To apply for career counseling, visit our 'Counseling' page and fill out the online form with your details.",
    },
    {
      question: "What services do you offer?",
      answer: "We provide personalized career counseling, admission guidance, test preparation, and career placement support for a wide range of industries.",
    },
    {
      question: "How do I track my application status?",
      answer: "You can check the status of your application by logging into your account and visiting the 'Application Status' section.",
    },
    {
      question: "Do you offer international counseling services?",
      answer: "Yes, we offer counseling for both domestic and international career opportunities, including studying abroad.",
    },
    {
      question: "Are your counseling sessions online or in-person?",
      answer: "Our counseling sessions are primarily online, but in-person sessions are available upon request for local clients.",
    },
    {
      question: "What is the fee for counseling services?",
      answer: "Our counseling fees vary based on the type of service. Visit the 'Pricing' page for more details.",
    },
    {
      question: "Can I change my counselor if I am not satisfied?",
      answer: "Yes, you can request a different counselor by contacting our support team, who will assist you in finding a better fit.",
    },
    {
      question: "How long does the counseling process take?",
      answer: "The process typically takes 1-2 weeks, depending on your specific needs and the availability of our counselors.",
    },
    {
      question: "Do you offer job placement assistance?",
      answer: "Yes, we provide job placement assistance through our network of employers and partners.",
    }
  ];

  const toggleFAQ = (index: number) => {
    if (selectedIndex === index) {
      setSelectedIndex(null);
    } else {
      setSelectedIndex(index);
    }
  };

  return (
    <div className="px-4 py-8 max-w-3xl mx-auto">
      <h2 className="text-3xl font-bold text-center mb-8">Frequently Asked Questions</h2>
      <div className="space-y-4">
        {faqs.map((faq, index) => (
          <div key={index} className="bg-white shadow-lg rounded-lg">
            <button
              className="w-full text-left p-4 text-lg font-semibold bg-gray-100 rounded-t-lg focus:outline-none flex items-center justify-between"
              onClick={() => toggleFAQ(index)}
            >
              {faq.question}
              <span className="text-xl">+</span> {/* Plus Icon */}
            </button>
            {selectedIndex === index && (
              <div className="p-4 bg-gray-50 text-gray-700 rounded-b-lg">
                {faq.answer}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default Faq;
