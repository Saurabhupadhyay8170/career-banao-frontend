import CareerModule from "components/main-website/career";
const Career = () => {
  return (
    <div>
      <CareerModule />
    </div>
  );
};

export default Career;
