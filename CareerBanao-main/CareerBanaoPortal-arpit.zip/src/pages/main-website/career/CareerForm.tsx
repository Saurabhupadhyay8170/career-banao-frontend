import Candidate from "components/main-website/job_apply_form/Candidate"

function CareerForm() {
  return (
    <div>
      <Candidate/> 
    </div>
  )
}

export default CareerForm
