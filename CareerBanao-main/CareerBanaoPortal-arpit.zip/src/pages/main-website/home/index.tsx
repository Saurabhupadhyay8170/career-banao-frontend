// home page for the website
import Section1 from "components/main-website/homePage/Section1";
import Section2 from "components/main-website/homePage/Section2";
import Section3 from "components/main-website/homePage/Section3";
import Section4 from "components/main-website/homePage/Section4";
import Section5 from "components/main-website/homePage/Section5";
import Section6 from "components/main-website/homePage/Section6";
import Faq from "src/components/main-website/faq/Faq";
function HomePage() {
  return (
    <div className="relative p-[20px] overflow-x-hidden">
      <Section1 />
      <Section2 />
      <Section3 />
      <Section4 />
      <Section5 />
      <Section6 />
      <Faq/>
    </div>
  );
}

export default HomePage;
